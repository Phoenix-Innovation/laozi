module github.com/laozi/plugin

go 1.21

require (
	github.com/sashabaranov/go-openai v1.20.0
)
